

typedef struct {
        PyObject_HEAD
        npy_bool obval;
} PyBoolScalarObject;

#define import_array()
#define PyArray_New _PyArray_New

